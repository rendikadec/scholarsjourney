# Assets

Folder ini disiapkan untuk mengganti placeholder CSS dengan asset final.

- `custom/university-logo.png` — logo universitas.
- `custom/graduation.mp3` — musik wisuda opsional.
- `sprites/` — sprite player, NPC, enemy, loot, Academic Tool.
- `backgrounds/` — background pixel-art kampus portrait.
- `audio/` — BGM/SFX tambahan jika nanti dipakai.

Game tetap berjalan tanpa asset tambahan karena versi v1.1 memiliki placeholder CSS/WebAudio bawaan.
